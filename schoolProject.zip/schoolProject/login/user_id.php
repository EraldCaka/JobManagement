<?php
session_start();
$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];
//echo $user_id;

?>