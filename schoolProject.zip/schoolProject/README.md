# JobManagement

This is a basic web application with 3 different type of users (guest, recruiter and admin). Lacking the style which soon will be updated since the main focus was the functionality of the database

## Admin

<li>Can check login
<li>Can lookup all the informations about anyone
<li>Can change its own information
<li>Can fire people(Still on process!)

## Recruiter

<li>Can check login
<li>Can lookup the job applications from the guests 
<li>Can reject a person if he doesn't sees him fit for the job position
<li>Can approve a person if he sees him fit 
<li>If a person gets approven his data will get placed into the users database among other admins,recrutiers,employees.

## Guest

<li>Can view the pages
<li>Can check the current vacant jobs
<li>Can apply for the job they want
<li>Can contact the company

## TO-DO

<li> css - styling 
<li> admin can fire people( removal from the users database )

## Recruitment applications database!

![image](https://user-images.githubusercontent.com/96385473/212551915-9d5a1dd0-fda1-4fa1-9e99-c0c9e8ed6194.png)

## Users database!

![image](https://user-images.githubusercontent.com/96385473/212554732-015bfa9d-87c0-474d-bf7c-930d50e00c76.png)

---

<strong>Contributors :[Erald Caka](https://github.com/EraldCaka) and [Kris Beka](https://github.com/KRIS13-GIF)</strong>
